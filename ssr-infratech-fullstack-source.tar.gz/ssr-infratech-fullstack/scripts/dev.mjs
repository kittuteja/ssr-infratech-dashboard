import {createServer} from 'node:http';
import {mkdirSync} from 'node:fs';
import {localDatabase} from './sqlite-d1.mjs';
import worker from '../dist/server/index.js';
mkdirSync('.sites-runtime',{recursive:true});const DB=localDatabase('.sites-runtime/development.sqlite');
const port=Number(process.env.PORT||4174);
createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://127.0.0.1:'+port);if(!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host)){res.writeHead(403);res.end('Local preview only');return;}
 const headers=new Headers(req.headers);for(const name of [...headers.keys()])if(name.startsWith('oai-authenticated-user-'))headers.delete(name);
 // Fixed local preview identity is supplied only by this loopback-bound server, never by the deployed Worker.
 headers.set('oai-authenticated-user-id','local-preview');headers.set('oai-authenticated-user-email','preview@localhost');headers.set('oai-authenticated-user-full-name','Local%20preview');headers.set('oai-authenticated-user-full-name-encoding','percent-encoded-utf-8');
 let body;if(!['GET','HEAD'].includes(req.method)){const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>20000){res.writeHead(413);res.end('Request too large');return;}chunks.push(chunk);}body=Buffer.concat(chunks);}
 const response=await worker.fetch(new Request(url,{method:req.method,headers,body}),{DB});res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch(error){console.error(error);res.writeHead(500);res.end('Preview server error');}}).listen(port,'127.0.0.1',()=>console.log('SSR full-stack preview: http://127.0.0.1:'+port+'/'));
