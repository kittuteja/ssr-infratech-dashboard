# SSR INFRATECH — Material Management

Full-stack inventory dashboard using SSR INFRATECH’s official logo and orange, cream and charcoal branding.

## Features

- Materials grouped by category, brand, supplier, specification and project.
- Receive and issue stock with movement date, recorded date, batch and reference.
- Automatic added/updated timestamps and authenticated user attribution.
- Stock history, edit history, low-stock alerts and CSV export.
- Shared persistent D1 database; version checks prevent concurrent lost updates and request keys protect retries.
- Private hosting with platform-managed sign-in. The hosting access policy controls who can use the shared company inventory.

## Local development

Use Node.js 24 or later for the local SQLite adapter and tests.

```sh
npm ci
npm test
npm run build
npm run dev
```

Open http://127.0.0.1:4174. Local preview supplies a fixed preview identity and uses `.sites-runtime/development.sqlite`. It is bound to loopback only; this identity adapter is not deployed.

## Deployment

`server/worker.mjs` handles assets and API routes. Production requires the private Sites authenticated gateway and its verified identity headers; do not expose the Worker through a separate public origin. The DB binding is configured in `.openai/hosting.json`. Production does not accept preview identities or trust client-supplied identity through the gateway.

`db/schema.ts` defines the database. Run `npm run db:generate` after schema changes; review and commit generated `drizzle/` SQL and metadata. Sites applies migrations before Worker deployment. Never edit previously applied migrations.

The Sites workflow builds `dist`, pushes exact source and publishes an archive. Source code is also maintained at https://github.com/kittuteja/ssr-infratech-dashboard.

The database starts empty. Prototype browser storage and local test data are not imported. There is no sample-data seeding.

## Scope

This release covers material inventory. Projects are currently configured as Nakshatra, HM Grandeur and Sri Sai Bhageeratha Residency. All authorized workspace users share the same inventory; separate staff roles, purchase-order workflows and accounting are not implemented. Inventory refreshes after a save or using Refresh.
